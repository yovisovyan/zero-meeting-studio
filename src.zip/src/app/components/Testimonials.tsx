// src/components/Testimonials.tsx
"use client";
import { motion } from "framer-motion";

const quotes = [
  { name: "Amanda R.", text: "The cleanest website process I've had in 10+ years. Fast, no meetings, and superb design.", img: "https://i.pravatar.cc/120?img=32", logo: "https://via.placeholder.com/80x28?text=Brand" },
  { name: "John M.", text: "Perfect for busy entrepreneurs. Zero meetings, perfect output.", img: "https://i.pravatar.cc/120?img=12", logo: "https://via.placeholder.com/80x28?text=Client" },
  { name: "Chris T.", text: "Delivered in 48 hours and looked incredibly premium.", img: "https://i.pravatar.cc/120?img=8", logo: "https://via.placeholder.com/80x28?text=Shop" },
];

export default function Testimonials() {
  return (
    <section className="max-w-6xl mx-auto px-6 py-28">
      <h3 className="text-3xl md:text-4xl font-semibold text-center mb-12">Loved by founders</h3>
      <div className="grid md:grid-cols-3 gap-8">
        {quotes.map((q, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }} className="p-6 rounded-2xl bg-white/4 border border-white/6">
            <div className="flex items-center gap-4 mb-4">
              <img src={q.img} alt={q.name} className="w-12 h-12 rounded-full object-cover" />
              <div>
                <div className="font-semibold">{q.name}</div>
                <div className="text-sm text-gray-300">Founder</div>
              </div>
            </div>

            <img src={q.logo} alt="client logo" className="mb-4 opacity-70" />

            <p className="italic text-gray-200 mb-4">“{q.text}”</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
