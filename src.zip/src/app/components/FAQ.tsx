// src/components/FAQ.tsx
"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";

const faqData = [
  { q: "Do we really not need any meetings?", a: "Correct. Everything is online — just fill the brief and we handle the rest." },
  { q: "How fast is delivery?", a: "Most landing pages ship in 48–72 hours. Business websites usually take 5–7 days." },
  { q: "Is revision included?", a: "Yes — revisions are included until you're happy with the result." },
  { q: "How do payments and taxes work?", a: "We accept Stripe/PayPal for international clients; invoices provided. We'll add payment flow on Start." },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <section className="max-w-4xl mx-auto px-6 py-20">
      <h3 className="text-3xl md:text-4xl font-semibold text-center mb-10">Frequently Asked Questions</h3>
      <div className="space-y-4">
        {faqData.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={i} className="bg-white/4 border border-white/8 rounded-2xl p-4">
              <button onClick={() => setOpen(isOpen ? null : i)} className="w-full flex items-center justify-between text-left">
                <div className="text-lg font-medium">{f.q}</div>
                <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.25 }}>
                  <ChevronDown />
                </motion.div>
              </button>

              <AnimatePresence>
                {isOpen && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.28 }} className="overflow-hidden mt-3">
                    <p className="text-gray-300">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </section>
  );
}
