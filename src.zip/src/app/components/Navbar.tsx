// src/components/Navbar.tsx
"use client";
import Link from "next/link";
import ThemeToggle from "./ThemeToggle";

export default function Navbar() {
  return (
    <header className="fixed top-0 left-0 w-full z-50 backdrop-blur-md bg-black/40 border-b border-white/6">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        <Link href="/" className="text-lg font-semibold">Zero-Meeting</Link>

        <nav className="hidden md:flex items-center gap-6">
          <a href="#pricing" className="text-sm opacity-90">Pricing</a>
          <a href="/blog" className="text-sm opacity-90">Blog</a>
          <a href="/start" className="rounded-full px-4 py-2 bg-white text-black text-sm font-medium">Start</a>
          <ThemeToggle />
        </nav>

        <div className="md:hidden flex items-center gap-3">
          <ThemeToggle />
          <a href="/start" className="rounded-full px-3 py-2 bg-white text-black text-sm">Start</a>
        </div>
      </div>
    </header>
  );
}
