// src/components/Mockup.tsx
"use client";
import { motion } from "framer-motion";
import Image from "next/image";
import { useState } from "react";

export default function Mockup() {
  const [hovered, setHovered] = useState(false);

  return (
    <section className="w-full py-32 flex justify-center">
      <div className="max-w-6xl w-full px-6">
        <div className="flex flex-col items-center text-center mb-10">
          <h2 className="text-4xl md:text-5xl font-bold mb-3">A New Level of Craft</h2>
          <p className="text-gray-400 max-w-2xl">Inspired by Apple’s signature floating product shots — polished, minimal, and beautiful.</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative flex justify-center"
        >
          <motion.div
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            animate={{
              rotateX: hovered ? 6 : 0,
              rotateY: hovered ? -8 : 0,
              scale: hovered ? 1.04 : 1,
              boxShadow: hovered ? "0px 40px 80px rgba(0,0,0,0.55)" : "0px 20px 40px rgba(0,0,0,0.35)"
            }}
            transition={{ type: "spring", stiffness: 200, damping: 18 }}
            style={{ perspective: 1200 }}
            className="relative w-full max-w-4xl aspect-[16/10] rounded-3xl overflow-hidden bg-neutral-900 border border-white/8"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-white/3 to-transparent mix-blend-overlay pointer-events-none" />
            <Image src="/mockup.jpg" alt="3D Mockup" fill className="object-cover" priority />
          </motion.div>
        </motion.div>

        <div className="text-center mt-10 text-gray-400">Interacts with your cursor. Smooth physics. Apple-grade detail.</div>
      </div>
    </section>
  );
}
