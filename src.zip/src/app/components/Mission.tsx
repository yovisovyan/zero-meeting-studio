// src/components/Mission.tsx
"use client";
import { motion } from "framer-motion";

export default function Mission() {
  return (
    <section className="w-full py-16 px-6">
      <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} className="max-w-5xl mx-auto bg-white/4 p-8 rounded-3xl border border-white/8">
        <h3 className="text-2xl font-semibold mb-3">Our Mission</h3>
        <p className="text-gray-300 leading-relaxed">
          Make premium digital execution accessible to entrepreneurs and creators who don't have time for slow agencies. We focus on world-class quality, zero wasted time, and lightning-fast delivery.
        </p>
      </motion.div>
    </section>
  );
}
