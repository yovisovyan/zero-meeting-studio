// src/components/Team.tsx
"use client";
import { motion } from "framer-motion";

const team = [
  { img: "https://i.pravatar.cc/160?img=15", name: "Yovi", role: "Founder & Lead Web Architect", desc: "$20k+ earned on Upwork. Specializing in landing pages & conversion UX." },
  { img: "https://i.pravatar.cc/160?img=16", name: "Design Partner", role: "Senior UI/UX Designer", desc: "Apple-inspired aesthetics. Clean, modern, conversion-first." },
  { img: "https://i.pravatar.cc/160?img=18", name: "Dev Partner", role: "Full-Stack Developer", desc: "Scalable custom features and integrations." },
];

export default function Team() {
  return (
    <section className="w-full py-24 px-6">
      <div className="max-w-6xl mx-auto text-center mb-8">
        <h3 className="text-3xl font-semibold">Meet the Team</h3>
        <p className="text-gray-400 max-w-2xl mx-auto mt-3">A small, elite, remote-first team — focused on execution over talk.</p>
      </div>

      <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-10">
        {team.map((m, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }} className="text-center">
            <img src={m.img} alt={m.name} className="w-36 h-36 mx-auto rounded-full bg-white/6 p-3 mb-4" />
            <h4 className="text-xl font-semibold">{m.name}</h4>
            <div className="text-gray-300">{m.role}</div>
            <p className="text-gray-400 mt-3 text-sm max-w-sm mx-auto">{m.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
