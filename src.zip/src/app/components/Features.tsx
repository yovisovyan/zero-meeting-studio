// src/components/Features.tsx
"use client";
import { Clock, PhoneOff, Star, Rocket, Globe, Users } from "lucide-react";
import { FadeUp } from "./Animated";

const features = [
  { icon: <Clock className="w-6 h-6" />, title: "Fast Turnaround", text: "Landing pages in 48–72 hours; websites 5–7 days." },
  { icon: <PhoneOff className="w-6 h-6" />, title: "Zero Meetings", text: "Complete the brief — we take it from there." },
  { icon: <Star className="w-6 h-6" />, title: "Conversion Focus", text: "Design + copy optimized for ads and signups." },
  { icon: <Rocket className="w-6 h-6" />, title: "Growth Ready", text: "Ad pixels, analytics, and fast hosting config." },
  { icon: <Globe className="w-6 h-6" />, title: "US Market Focus", text: "UX & copy tuned for USA audiences." },
  { icon: <Users className="w-6 h-6" />, title: "Partner Network", text: "Designers & devs available on demand." },
];

export default function Features() {
  return (
    <section className="max-w-6xl mx-auto px-6 py-20">
      <h3 className="text-3xl md:text-4xl font-semibold text-center mb-12">What we deliver</h3>
      <div className="grid md:grid-cols-3 gap-8">
        {features.map((f, i) => (
          <FadeUp key={i} delay={i * 0.05}>
            <div className="bg-white/4 p-6 rounded-2xl border border-white/6">
              <div className="w-12 h-12 flex items-center justify-center bg-white/6 rounded-lg mb-4">{f.icon}</div>
              <h4 className="text-xl font-semibold mb-2">{f.title}</h4>
              <p className="text-gray-300">{f.text}</p>
            </div>
          </FadeUp>
        ))}
      </div>
    </section>
  );
}
