// src/components/Hero.tsx
"use client";
import { motion } from "framer-motion";
import { FadeUp } from "./Animated";

export default function Hero() {
  return (
    <section className="relative max-w-7xl mx-auto px-6 pt-36 pb-28 text-center overflow-visible">
      <div className="absolute left-1/2 top-16 -translate-x-1/2 hero-glow w-[780px] h-[420px] bg-gradient-to-br from-indigo-600 to-cyan-400 rounded-full opacity-30 pointer-events-none" />

      <FadeUp>
        <h1 className="text-5xl md:text-7xl font-semibold tracking-tight leading-tight">
          Beautiful Websites.
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-300">Zero Meetings.</span>
        </h1>
      </FadeUp>

      <FadeUp delay={0.08}>
        <p className="mt-6 text-lg md:text-xl text-gray-300 max-w-2xl mx-auto">
          A seamless, fast, premium website-building experience designed for modern founders who value speed and clarity.
        </p>
      </FadeUp>

      <FadeUp delay={0.16}>
        <div className="mt-10 flex justify-center gap-4">
          <a href="/start" className="px-10 py-4 rounded-full bg-white text-black text-lg font-medium shadow-lg hover:scale-[1.02] transition">Start Now</a>
          <a href="#pricing" className="px-10 py-4 rounded-full border border-white/20 text-lg font-medium hover:bg-white/6 transition">Pricing</a>
        </div>
      </FadeUp>

      <div className="relative z-10 mt-10 flex justify-center gap-6 text-sm text-gray-400">
        <div><strong className="text-white">48–72h</strong> delivery</div>
        <div>Shopify & custom</div>
        <div>Conversion-first design</div>
      </div>
    </section>
  );
}
