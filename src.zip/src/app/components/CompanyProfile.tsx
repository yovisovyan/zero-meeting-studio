// src/components/CompanyProfile.tsx
"use client";
import { motion } from "framer-motion";

export default function CompanyProfile() {
  return (
    <section className="w-full py-24 px-6">
      <motion.div initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} className="max-w-5xl mx-auto text-center">
        <img src="https://cdn-icons-png.flaticon.com/512/9068/9068678.png" alt="company" className="w-16 h-16 mx-auto mb-4 opacity-90" />
        <h3 className="text-3xl font-semibold mb-4">Who We Are</h3>
        <p className="text-gray-300 max-w-3xl mx-auto leading-relaxed mb-6">
          Zero-Meeting Studio is a global web agency built for modern business owners who value speed, clarity, and results. Based in Indonesia, serving clients worldwide — especially the USA.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
          <div><div className="text-3xl font-extrabold">20K+</div><div className="text-sm text-gray-400">Upwork earnings</div></div>
          <div><div className="text-3xl font-extrabold">200+</div><div className="text-sm text-gray-400">Projects delivered</div></div>
          <div><div className="text-3xl font-extrabold">99%</div><div className="text-sm text-gray-400">Client satisfaction</div></div>
          <div><div className="text-3xl font-extrabold">USA</div><div className="text-sm text-gray-400">Primary market</div></div>
        </div>
      </motion.div>
    </section>
  );
}
