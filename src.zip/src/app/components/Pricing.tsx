// src/components/Pricing.tsx
"use client";
import { motion } from "framer-motion";

const plans = [
  { title: "Landing Page", price: "$149", items: ["1-page modern design", "Mobile-friendly", "Copy guidance", "48h delivery"] },
  { title: "Business Website", price: "$399", items: ["Up to 5 pages", "SEO basics", "Brand-consistent design", "72h delivery"] },
  { title: "Shopify Store", price: "$499", items: ["Full Shopify setup", "Product templates", "Launch support", "7–10 days"] },
];

export default function Pricing() {
  return (
    <section id="pricing" className="max-w-6xl mx-auto px-6 py-28">
      <h3 className="text-3xl md:text-4xl font-semibold text-center mb-8">Simple, Transparent Pricing</h3>
      <div className="grid md:grid-cols-3 gap-8">
        {plans.map((p, i) => (
          <motion.div key={p.title} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }} className="p-10 rounded-3xl bg-white/4 border border-white/8 backdrop-blur-xl">
            <div className="text-xl font-medium mb-2">{p.title}</div>
            <div className="text-5xl font-extrabold mb-6">{p.price}</div>
            <ul className="text-gray-300 space-y-2 mb-6">
              {p.items.map((it) => <li key={it}>• {it}</li>)}
            </ul>
            <a href="/start" className="inline-block px-8 py-3 rounded-full bg-white text-black font-semibold">Start</a>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
