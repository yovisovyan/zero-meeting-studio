// src/app/page.tsx

import Hero from "@/app/components/Hero";
import Mockup from "@/app/components/Mockup";
import Features from "@/app/components/Features";
import Testimonials from "@/app/components/Testimonials";
import Pricing from "@/app/components/Pricing";
import FAQ from "@/app/components/FAQ";
import CompanyProfile from "@/app/components/CompanyProfile";
import Mission from "@/app/components/Mission";
import Team from "@/app/components/Team";
import Footer from "@/app/components/Footer";

export default function Page() {
  return (
    <main className="min-h-screen w-full overflow-hidden bg-black text-white">
      <Hero />
      <Mockup />
      <Features />
      <Testimonials />
      <Pricing />
      <FAQ />
      <CompanyProfile />
      <Mission />
      <Team />
      <Footer />
    </main>
  );
}
